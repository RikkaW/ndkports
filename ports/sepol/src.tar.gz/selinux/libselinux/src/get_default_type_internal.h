#include <selinux/get_default_type.h>

