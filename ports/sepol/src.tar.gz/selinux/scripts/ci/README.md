# Continuous Integration Scripts

The scripts under `scripts/ci` are designed specifically
for the Travis CI system. While nothing prevents you
from mimicking that environment and using them locally,
they are not applicable for general consumption. Any
thing in this directory should never be considered as
a stable API.
